package oracle.view;

import java.util.Calendar;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.domain.Number;


public class EmployeeBean {
    private Number empId;
    private String empFirstName;
    private String empLastName;
    private String fullName;
    private Number salary;
    private Number deptId;
    private boolean showDetails = false;

    public EmployeeBean() {
    }

    public void fetchEmployeeDetails(ActionEvent actionEvent) {
        Number empId = this.getEmpId();
        System.out.println("empId: " + empId);

        if (empId == null) {
            showMessage("Please enter a valid employee ID",
                        FacesMessage.SEVERITY_ERROR);
            showDetails = false;
        } else {
            OperationBinding ob =
                BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("getEmployeeDetailsById");
            ob.getParamsMap().put("empId", empId);
            Object result = ob.execute();

            if (!ob.getErrors().isEmpty()) {
                showMessage("Error executing operation binding",
                            FacesMessage.SEVERITY_ERROR);
                showDetails = false;
                return;
            }

            if (result instanceof Row) {
                Row row = (Row)result;

                this.setEmpId((Number)row.getAttribute("EmployeeId"));
                String firstName = (String)row.getAttribute("FirstName");
                String lastName = (String)row.getAttribute("LastName");
                this.setEmpFirstName(firstName);
                this.setEmpLastName(lastName);
                this.setFullName(firstName + " " + lastName);
                this.setSalary((Number)row.getAttribute("Salary"));
                this.setDeptId((Number)row.getAttribute("DepartmentId"));
                showDetails = true;

                // Calculate duration from HireDate to today
                oracle.jbo.domain.Date jboDate =
                    (oracle.jbo.domain.Date)row.getAttribute("HireDate");
                if (jboDate != null) {
                    java.util.Date hireDate = jboDate.getValue();
                    Calendar start = Calendar.getInstance();
                    start.setTime(hireDate);
                    Calendar end = Calendar.getInstance();

                    int years =
                        end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
                    int months =
                        end.get(Calendar.MONTH) - start.get(Calendar.MONTH);
                    int days =
                        end.get(Calendar.DAY_OF_MONTH) - start.get(Calendar.DAY_OF_MONTH);

                    if (days < 0) {
                        months--;
                        days += end.getActualMaximum(Calendar.DAY_OF_MONTH);
                    }
                    if (months < 0) {
                        years--;
                        months += 12;
                    }

                    String duration =
                        years + " years, " + months + " months, " + days +
                        " days";
                    showMessage("Employee: " + this.fullName +
                                "\nCongratulations You have Succusses fully Completed in our Organization: " +
                                duration, FacesMessage.SEVERITY_INFO);
                } else {
                    showMessage("Hire Date is not available",
                                FacesMessage.SEVERITY_WARN);
                }

            } else {
                showDetails = false;
                showMessage("EmployeeId: " + empId +
                            " not found in Employee Table",
                            FacesMessage.SEVERITY_ERROR);
            }
        }
    }

    private void showMessage(String message, FacesMessage.Severity severity) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(severity, message, null));
    }

    // Getters and Setters

    public void setEmpId(Number empId) {
        this.empId = empId;
    }

    public Number getEmpId() {
        return empId;
    }

    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    public String getEmpFirstName() {
        return empFirstName;
    }

    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    public String getEmpLastName() {
        return empLastName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setSalary(Number salary) {
        this.salary = salary;
    }

    public Number getSalary() {
        return salary;
    }

    public void setDeptId(Number deptId) {
        this.deptId = deptId;
    }

    public Number getDeptId() {
        return deptId;
    }

    public void setShowDetails(boolean showDetails) {
        this.showDetails = showDetails;
    }

    public boolean isShowDetails() {
        return showDetails;
    }
}
